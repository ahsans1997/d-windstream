<?php

namespace App\Http\Controllers;

use App\Models\FacultyMemberResearchInvitedTalk;
use Illuminate\Http\Request;

class FacultyMemberResearchInvitedTalkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\FacultyMemberResearchInvitedTalk  $facultyMemberResearchInvitedTalk
     * @return \Illuminate\Http\Response
     */
    public function show(FacultyMemberResearchInvitedTalk $facultyMemberResearchInvitedTalk)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\FacultyMemberResearchInvitedTalk  $facultyMemberResearchInvitedTalk
     * @return \Illuminate\Http\Response
     */
    public function edit(FacultyMemberResearchInvitedTalk $facultyMemberResearchInvitedTalk)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\FacultyMemberResearchInvitedTalk  $facultyMemberResearchInvitedTalk
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FacultyMemberResearchInvitedTalk $facultyMemberResearchInvitedTalk)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\FacultyMemberResearchInvitedTalk  $facultyMemberResearchInvitedTalk
     * @return \Illuminate\Http\Response
     */
    public function destroy(FacultyMemberResearchInvitedTalk $facultyMemberResearchInvitedTalk)
    {
        //
    }
}
