<?php

namespace App\Http\Controllers;

use App\Models\ProgramCurriculamCours;
use Illuminate\Http\Request;

class ProgramCurriculamCoursController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ProgramCurriculamCours  $programCurriculamCours
     * @return \Illuminate\Http\Response
     */
    public function show(ProgramCurriculamCours $programCurriculamCours)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ProgramCurriculamCours  $programCurriculamCours
     * @return \Illuminate\Http\Response
     */
    public function edit(ProgramCurriculamCours $programCurriculamCours)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ProgramCurriculamCours  $programCurriculamCours
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProgramCurriculamCours $programCurriculamCours)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ProgramCurriculamCours  $programCurriculamCours
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProgramCurriculamCours $programCurriculamCours)
    {
        //
    }
}
