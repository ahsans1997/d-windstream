<?php

namespace App\Http\Controllers;

use App\Models\FacultyMemberResearchInterest;
use Illuminate\Http\Request;

class FacultyMemberResearchInterestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\FacultyMemberResearchInterest  $facultyMemberResearchInterest
     * @return \Illuminate\Http\Response
     */
    public function show(FacultyMemberResearchInterest $facultyMemberResearchInterest)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\FacultyMemberResearchInterest  $facultyMemberResearchInterest
     * @return \Illuminate\Http\Response
     */
    public function edit(FacultyMemberResearchInterest $facultyMemberResearchInterest)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\FacultyMemberResearchInterest  $facultyMemberResearchInterest
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FacultyMemberResearchInterest $facultyMemberResearchInterest)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\FacultyMemberResearchInterest  $facultyMemberResearchInterest
     * @return \Illuminate\Http\Response
     */
    public function destroy(FacultyMemberResearchInterest $facultyMemberResearchInterest)
    {
        //
    }
}
