<?php

namespace App\Http\Controllers;

use App\Models\FacultyMemberMembership;
use Illuminate\Http\Request;

class FacultyMemberMembershipController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\FacultyMemberMembership  $facultyMemberMembership
     * @return \Illuminate\Http\Response
     */
    public function show(FacultyMemberMembership $facultyMemberMembership)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\FacultyMemberMembership  $facultyMemberMembership
     * @return \Illuminate\Http\Response
     */
    public function edit(FacultyMemberMembership $facultyMemberMembership)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\FacultyMemberMembership  $facultyMemberMembership
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, FacultyMemberMembership $facultyMemberMembership)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\FacultyMemberMembership  $facultyMemberMembership
     * @return \Illuminate\Http\Response
     */
    public function destroy(FacultyMemberMembership $facultyMemberMembership)
    {
        //
    }
}
