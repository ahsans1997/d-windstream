<?php

namespace Database\Seeders;

use App\Models\Faculty;
use Illuminate\Database\Seeder;

class FacultySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [
                    [
                        'name' => "Textile Engenering",
                    ]
            ];

        foreach($data as $faculty){
            Faculty::create($faculty);
        }
    }
}
